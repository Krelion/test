#!/bin/bash

# Start apache
/usr/sbin/apache2 -D FOREGROUND